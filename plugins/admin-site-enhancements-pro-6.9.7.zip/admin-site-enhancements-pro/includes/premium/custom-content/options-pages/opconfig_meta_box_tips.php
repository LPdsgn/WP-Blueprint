<div class="tips-wrapper">
    <ul>
        <li><span class="dashicons dashicons-yes"></span> Once you've created this options page and can see the menu item where they should be, proceed by creating the field group and set the placement to this options page.</li>
    </ul>
    <a href="https://www.wpase.com/documentation/custom-field-types/" class="button">View documentation</a>
</div>
