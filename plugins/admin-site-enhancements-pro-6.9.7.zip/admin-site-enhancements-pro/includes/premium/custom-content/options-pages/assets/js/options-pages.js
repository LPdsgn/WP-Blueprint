(function($) {
   'use strict';

	$(document).ready( function() {
		$('h1.wp-heading-inline').html(optionsPage.heading)
		$('h1.wp-heading-inline').css('visibility','visible')
	});
})(jQuery);				
