import { handleSettingsTabs } from './settings/tabs'
import { handleEditorPreviewUpdates } from './settings/editor-preview'

handleSettingsTabs()
handleEditorPreviewUpdates()
