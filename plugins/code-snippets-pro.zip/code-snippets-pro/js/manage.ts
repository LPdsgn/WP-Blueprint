import { handleSnippetActivationSwitches } from './manage/activation'
import { handleSnippetPriorityChanges } from './manage/priority'

handleSnippetActivationSwitches()
handleSnippetPriorityChanges()
