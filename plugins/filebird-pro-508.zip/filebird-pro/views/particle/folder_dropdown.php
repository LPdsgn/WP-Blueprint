<div class="fbv-upload-inline">
    <label for="fbv"><?php esc_html_e( 'Choose folder: ', 'filebird' ); ?></label>
    <div id="fbv-folder-selector" class="fbv-folder-selector" name="fbv"></div>
</div>